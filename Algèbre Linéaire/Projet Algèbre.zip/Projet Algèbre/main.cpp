#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <SDL/SDL.h>
#include <SDL_image.h>
#include <math.h>

using namespace std;

void afficherLignes(double points3[][4], int point1, int point2, SDL_Surface *pixel, SDL_Surface *screen, SDL_Rect position[]);
void calculModel(double points[][4], double points1[][4], double matricemodel[][4], double var1, double var2, double var3, int valeur);
void reinitMatrice (double matricemodel[][4]);
void calculView(double points1[][4], double points2[][4], double matriceview[][4]);
void calculProjection(double points2[][4], double points3[][4], double matriceprojection[][4]);
void afficherMaison(double points3[][4], SDL_Surface *pixel, SDL_Surface *screen, SDL_Rect *position);
void divisionW(double points3[][4]);
double convertDegreRad(double degre);
void initMaison(double points[][4], double points1[][4], double points2[][4], double points3[][4], double matricemodel[][4], double matriceview[][4], double matriceprojection[][4], SDL_Surface *pixel, SDL_Surface *screen, SDL_Rect *position);

int main (int argc, char** argv)
{
    SDL_Surface *screen = NULL, *pixel = NULL, *fond = NULL;
    SDL_Event event;
    SDL_Rect position[15], position_fond;

    int continuer = 1, i, j, k, m, t = 0, c = 0;
    double points[14][4];
    double points1[14][4] = {0};
    double points2[14][4] = {0};
    double points3[14][4] = {0};
    double angle_degree_z, angle_radian_z, angle_degree_x, angle_radian_x;
    double pos_x = 0, pos_y = 0, pos_z = -2;

    angle_degree_z = 46;
    angle_radian_z = 0;

    angle_degree_x = 0;
    angle_radian_x = 0;

    position_fond.x = 0;
    position_fond.y = 0;

    points[0] = {0,0,0,1};
    points[1] = {0,3,0,1};
    points[2] = {4,0,0,1};
    points[3] = {4,1,0,1};
    points[4] = {4,2,0,1};
    points[5] = {4,3,0,1};
    points[6] = {0,0,3,1};
    points[7] = {0,3,3,1};
    points[8] = {4,0,3,1};
    points[9] = {4,3,3,1};
    points[10] = {4,1,2,1};
    points[11] = {4,2,2,1};
    points[12] = {0,1.5,4.5,1};
    points[13] = {4,1.5,4.5,1};

    SDL_Init(SDL_INIT_VIDEO);
    freopen("CONOUT$", "wb", stdout);
    freopen("CONOUT$", "wb", stderr);
    freopen("CONIN$", "rb", stdin);

    screen = SDL_SetVideoMode(600, 600, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
    SDL_WM_SetCaption("Projet Algebre Lineaire", NULL);
    SDL_WM_SetIcon(IMG_Load("img.GIF"), NULL);

    pixel = IMG_Load("pixel.jpg");
    fond = IMG_Load("fond.jpg");

    // on affiche

    SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 29, 83, 205));
    SDL_BlitSurface(fond, NULL, screen, &position_fond);

    double matricemodel[4][4] = {sqrt(2)/2, -sqrt(2)/2, 0, 0,
                                 sqrt(2)/2, sqrt(2)/2, 0, 0,
                                 0, 0, 1, -2,
                                 0, 0, 0, 1};


    double matriceview[4][4] = {-1, 0, 0, 0,
                                0, 0, -1, 0,
                                0, 1, 0, -34,
                                0, 0, 0, 1};


    // projection perspective
    /*double matriceprojection[4][4] = {1.921, 0, 0, 0,
                                      0, 1.921, 0, 0,
                                      0, 0, -1.5, -2.5,
                                      0, 0, -0.5, 0};*/

    // projection orthogonale
    double matriceprojection[4][4] = {0.20, 0, 0, 0,
                                      0, 0.20, 0, 0,
                                      0, 0, -0.22, -1.22,
                                      0, 0, 0, 1};


    // Initialisation Maison : calcul les points et affiche la maison
    initMaison(points, points1, points2, points3, matricemodel, matriceview, matriceprojection, pixel, screen, position);

    SDL_EnableKeyRepeat(200, 10); /* Activation de la r�p�tition des touches */
    while(continuer)
    {
        SDL_WaitEvent(&event);
        switch(event.type)
        {
            case SDL_QUIT:
            continuer = 0;
            break;
            case SDL_KEYDOWN:
            switch(event.key.keysym.sym)
            {
                case SDLK_t: //on change de mode translation/rotation ou rotation/translation
                t++;
                cout << "t : " << t << endl;
                break;
                case SDLK_0: //on remet la maison dans sa position initial
                SDL_BlitSurface(fond, NULL, screen, &position_fond);

                //remise � zero des angles
                angle_degree_z = 46;
                angle_radian_z = 0;
                angle_degree_x = 0;
                angle_radian_x = 0;
                pos_x = 0;
                pos_y = 0;
                pos_z = -2;

                //on recalcule les points pour r�afficher la maison � sa position initial
                calculModel(points, points1, matricemodel, 0, 0, 0, 0);
                calculView(points1, points2, matriceview);
                calculProjection(points2, points3, matriceprojection);
                divisionW(points3);

                afficherMaison(points3, pixel, screen, position);

                for(i = 0; i < 14; i++)
                {
                    for(j = 0; j < 4 ;j++)
                    {
                        points1[i][j] = 0;
                        points2[i][j] = 0;
                        points3[i][j] = 0;
                    }
                }
                break;
                case SDLK_c:
                c++;
                SDL_BlitSurface(fond, NULL, screen, &position_fond);
                if(c %2 == 0) // on annule le cisaillement
                    calculModel(points, points1, matricemodel, 0, 0, 0, 6);
                else
                    calculModel(points, points1, matricemodel, 0, 0, 0, 5);
                calculView(points1, points2, matriceview);
                calculProjection(points2, points3, matriceprojection);
                divisionW(points3);
                afficherMaison(points3, pixel, screen, position);
                for(i = 0; i < 14; i++)
                    {
                        for(j = 0; j < 4 ;j++)
                        {
                            points1[i][j] = 0;
                            points2[i][j] = 0;
                            points3[i][j] = 0;
                        }
                    }
                break;
                case SDLK_b: // Tremblement de terre
                    pos_x = (rand() % 5) / 15.0;
                    SDL_BlitSurface(fond, NULL, screen, &position_fond);
                    calculModel(points, points1, matricemodel, pos_x, 0, -2, 4);
                    calculView(points1, points2, matriceview);
                    calculProjection(points2, points3, matriceprojection);
                    divisionW(points3);
                    afficherMaison(points3, pixel, screen, position);
                    for(i = 0; i < 14; i++)
                    {
                        for(j = 0; j < 4 ;j++)
                        {
                            points1[i][j] = 0;
                            points2[i][j] = 0;
                            points3[i][j] = 0;
                        }
                    }

                break;
                case SDLK_w:
                SDL_BlitSurface(fond, NULL, screen, &position_fond);
                calculModel(points, points1, matricemodel, 0, 0, 0, 7);
                calculView(points1, points2, matriceview);
                calculProjection(points2, points3, matriceprojection);
                divisionW(points3);
                afficherMaison(points3, pixel, screen, position);

                for(i = 0; i < 14; i++)
                {
                    for(j = 0; j < 4 ;j++)
                    {
                        points1[i][j] = 0;
                        points2[i][j] = 0;
                        points3[i][j] = 0;
                    }
                }
                break;
                case SDLK_a:
                SDL_BlitSurface(fond, NULL, screen, &position_fond);
                calculModel(points, points1, matricemodel, 0, 0, 0, 8);
                calculView(points1, points2, matriceview);
                calculProjection(points2, points3, matriceprojection);
                divisionW(points3);
                afficherMaison(points3, pixel, screen, position);

                for(i = 0; i < 14; i++)
                {
                    for(j = 0; j < 4 ;j++)
                    {
                        points1[i][j] = 0;
                        points2[i][j] = 0;
                        points3[i][j] = 0;
                    }
                }
                break;
                case SDLK_RIGHT:
                if(t % 2 == 0) // Rotation
                {
                    SDL_BlitSurface(fond, NULL, screen, &position_fond);
                    angle_degree_z += 5;
                    angle_radian_z = convertDegreRad(angle_degree_z);

                    calculModel(points, points1, matricemodel, cos(angle_radian_z), sin(angle_radian_z), 0, 1);
                    calculView(points1, points2, matriceview);
                    calculProjection(points2, points3, matriceprojection);
                    divisionW(points3);
                    afficherMaison(points3, pixel, screen, position);

                    for(i = 0; i < 14; i++)
                    {
                        for(j = 0; j < 4 ;j++)
                        {
                            points1[i][j] = 0;
                            points2[i][j] = 0;
                            points3[i][j] = 0;
                        }
                    }
                }
                else // Translation
                {
                    SDL_BlitSurface(fond, NULL, screen, &position_fond);
                    pos_x -= 1 / 5.0;
                    calculModel(points, points1, matricemodel, pos_x, pos_y, pos_z, 4);
                    calculView(points1, points2, matriceview);
                    calculProjection(points2, points3, matriceprojection);
                    divisionW(points3);
                    afficherMaison(points3, pixel, screen, position);

                    for(i = 0; i < 14; i++)
                    {
                        for(j = 0; j < 4 ;j++)
                        {
                            points1[i][j] = 0;
                            points2[i][j] = 0;
                            points3[i][j] = 0;
                        }
                    }
                }
                break;
                case SDLK_LEFT:
                if(t % 2 == 0) // Rotation
                {
                    SDL_BlitSurface(fond, NULL, screen, &position_fond);
                    angle_degree_z -= 5;
                    angle_radian_z = convertDegreRad(angle_degree_z);

                    calculModel(points, points1, matricemodel, cos(angle_radian_z), sin(angle_radian_z), 0, 1);
                    calculView(points1, points2, matriceview);
                    calculProjection(points2, points3, matriceprojection);
                    divisionW(points3);
                    afficherMaison(points3, pixel, screen, position);

                    for(i = 0; i < 14; i++)
                    {
                        for(j = 0; j < 4 ;j++)
                        {
                            points1[i][j] = 0;
                            points2[i][j] = 0;
                            points3[i][j] = 0;
                        }
                    }
                }
                else // Translation
                {
                    SDL_BlitSurface(fond, NULL, screen, &position_fond);
                    pos_x += 1 / 5.0;
                    calculModel(points, points1, matricemodel, pos_x, pos_y, pos_z, 4);
                    calculView(points1, points2, matriceview);
                    calculProjection(points2, points3, matriceprojection);
                    divisionW(points3);
                    afficherMaison(points3, pixel, screen, position);

                    for(i = 0; i < 14; i++)
                    {
                        for(j = 0; j < 4 ;j++)
                        {
                            points1[i][j] = 0;
                            points2[i][j] = 0;
                            points3[i][j] = 0;
                        }
                    }
                }
                break;

                case SDLK_UP:
                if(t % 2 == 0) // Rotation
                {
                    SDL_BlitSurface(fond, NULL, screen, &position_fond);
                    angle_degree_x += 5;
                    angle_radian_x = convertDegreRad(angle_degree_x);

                    calculModel(points, points1, matricemodel, cos(angle_radian_x), sin(angle_radian_x), 0, 2);
                    calculView(points1, points2, matriceview);
                    calculProjection(points2, points3, matriceprojection);
                    divisionW(points3);
                    afficherMaison(points3, pixel, screen, position);

                    for(i = 0; i < 14; i++)
                    {
                        for(j = 0; j < 4 ;j++)
                        {
                            points1[i][j] = 0;
                            points2[i][j] = 0;
                            points3[i][j] = 0;
                        }
                    }
                }
                else // Translation
                {
                    SDL_BlitSurface(fond, NULL, screen, &position_fond);
                    pos_z += 1 / 5.0;
                    calculModel(points, points1, matricemodel, pos_x, pos_y, pos_z, 4);
                    calculView(points1, points2, matriceview);
                    calculProjection(points2, points3, matriceprojection);
                    divisionW(points3);
                    afficherMaison(points3, pixel, screen, position);

                    for(i = 0; i < 14; i++)
                    {
                        for(j = 0; j < 4 ;j++)
                        {
                            points1[i][j] = 0;
                            points2[i][j] = 0;
                            points3[i][j] = 0;
                        }
                    }
                }
                break;
                case SDLK_DOWN:
                if(t % 2 == 0) // Rotation
                {
                    SDL_BlitSurface(fond, NULL, screen, &position_fond);
                    angle_degree_x -= 5;
                    angle_radian_x = convertDegreRad(angle_degree_x);

                    calculModel(points, points1, matricemodel, cos(angle_radian_x), sin(angle_radian_x), 0, 2);
                    calculView(points1, points2, matriceview);
                    calculProjection(points2, points3, matriceprojection);
                    divisionW(points3);
                    afficherMaison(points3, pixel, screen, position);

                    for(i = 0; i < 14; i++)
                    {
                        for(j = 0; j < 4 ;j++)
                        {
                            points1[i][j] = 0;
                            points2[i][j] = 0;
                            points3[i][j] = 0;
                        }
                    }
                }
                else // Translation
                {
                    SDL_BlitSurface(fond, NULL, screen, &position_fond);
                    pos_z -= 1 / 5.0;
                    calculModel(points, points1, matricemodel, pos_x, pos_y, pos_z, 4);
                    calculView(points1, points2, matriceview);
                    calculProjection(points2, points3, matriceprojection);
                    divisionW(points3);
                    afficherMaison(points3, pixel, screen, position);

                    for(i = 0; i < 14; i++)
                    {
                        for(j = 0; j < 4 ;j++)
                        {
                            points1[i][j] = 0;
                            points2[i][j] = 0;
                            points3[i][j] = 0;
                        }
                    }
                }
                break;
                default:
                break;
            }
            break;
            default:
            break;
        }
        position_fond.x = 0;
        position_fond.y = 0;
        SDL_Flip(screen);
    }

    SDL_FreeSurface(screen);
    SDL_FreeSurface(pixel);
    SDL_Quit();
    return 0;
}

void initMaison(double points[][4], double points1[][4], double points2[][4], double points3[][4], double matricemodel[][4], double matriceview[][4], double matriceprojection[][4], SDL_Surface *pixel, SDL_Surface *screen, SDL_Rect *position)
{
    int i, j;

    //matrice indicielle
    calculModel(points, points1, matricemodel, sqrt(2)/2, sqrt(2)/2, 0, 1);
    // Calcul avec la matrice view
    calculView(points1, points2, matriceview);
    // Calcul des points projet�s
    calculProjection(points2, points3, matriceprojection);
    // divise par w
    divisionW(points3);
    //on affiche la maison
    afficherMaison(points3, pixel, screen, position);

    for(i = 0; i < 14; i++)
    {
        for(j = 0; j < 4 ;j++)
        {
            points1[i][j] = 0;
            points2[i][j] = 0;
            points3[i][j] = 0;
        }
    }

    SDL_Flip(screen);
}


void afficherLignes(double points3[][4], int point1, int point2, SDL_Surface *pixel, SDL_Surface *screen, SDL_Rect position[])
{
    double x = points3[point2][0] - points3[point1][0];
    double y = points3[point2][1] - points3[point1][1];
    double length = sqrt(x*x + y*y);

    double addx = x / length;
    double addy = y / length;

    x = points3[point1][0];
    y = points3[point1][1];

    for(double i = 0; i < length; i += 1)
    {
        position[15].x = x;
        position[15].y = y;
        SDL_BlitSurface(pixel, NULL, screen, &position[15]);
        x += addx;
        y += addy;
    }
}

void reinitMatrice(double matricemodel[][4])
{
    int i, j;
    for(i = 0; i < 4; i++)
    {
        for(j = 0; j < 4 ;j++)
        {
            matricemodel[i][j] = 0;
        }
    }
    matricemodel[0][0] = sqrt(2)/2;
    matricemodel[0][1] = -sqrt(2)/2;
    matricemodel[1][0] = sqrt(2)/2;
    matricemodel[1][1] = sqrt(2)/2;
    matricemodel[2][2] = 1;
    matricemodel[2][3] = -2;
    matricemodel[3][3] = 1;
}

void calculModel(double points[][4], double points1[][4], double matricemodel[][4], double var1, double var2, double var3, int valeur)
{
    int i, j, k, m, caca = 0;

    double points_temp[14][4];

    switch(valeur)
    {
        case 0: // R�initialisation
        reinitMatrice(matricemodel);
        break;
        case 1: // Rotation autour de Oz
        matricemodel[0][0] = var1;
        matricemodel[0][1] = -var2;
        matricemodel[1][0] = var2;
        matricemodel[1][1] = var1;
        break;
        case 2: // Rotation autour de Ox
        matricemodel[1][1] = var1;
        matricemodel[1][2] = -var2;
        matricemodel[2][1] = var2;
        matricemodel[2][2] = var1;
        break;
        case 3: // Rotation autour de Oy
        matricemodel[1][1] = var1;
        matricemodel[1][2] = -var2;
        matricemodel[2][1] = var2;
        matricemodel[2][2] = var1;
        break;
        case 4: // Translation sur Ox
        matricemodel[0][3] = var1;
        matricemodel[1][3] = var2;
        matricemodel[2][3] = var3;
        break;
        case 5: // cisaillement
        matricemodel[2][0] = 1;
        break;
        case 6: // non cisaillement
        matricemodel[2][0] = 0;
        break;
        case 7: // Sym�trie autour de Ox
        matricemodel[0][0] = matricemodel[0][0];
        matricemodel[1][1] = -matricemodel[1][1];
        matricemodel[2][2] = -matricemodel[2][2];
        break;
        case 8: // Sym�trie autour de Oz
        matricemodel[0][0] = -matricemodel[0][0];
        matricemodel[1][1] = -matricemodel[1][1];
        matricemodel[2][2] = matricemodel[2][2];
        break;
        default:
        break;
    }

    for (i = 0; i < 14; i++)
    {
        for (j = 0; j < 4; j++)
        {
            m = 0;
            for (k = 0; k < 4; k++)
            {
                points1[i][j] = points[i][m] * matricemodel[j][k] + points1[i][j];
                m++;
            }
        }
    }
}

void calculView(double points1[][4], double points2[][4], double matriceview[][4])
{
    int i, j, k, m;

    for (i = 0; i < 14; i++)
    {
        for (j = 0; j < 4; j++)
        {
            m = 0;
            for (k = 0; k < 4; k++)
            {
                points2[i][j] = points1[i][m] * matriceview[j][k] + points2[i][j];
                m++;
            }
        }
    }
}

void calculProjection(double points2[][4], double points3[][4], double matriceprojection[][4])
{
    int i, j, k, m;
    for (i = 0; i < 14; i++)
    {
        for (j = 0; j < 4; j++)
        {
            m = 0;
            for (k = 0; k < 4; k++)
            {
                points3[i][j] = points2[i][m] * matriceprojection[j][k] + points3[i][j];
                m++;
            }
        }
    }
}

void divisionW(double points3[][4])
{
    int i, j;
    for(i = 0; i < 14; i++)
    {
        for(j = 0; j < 4; j++)
        {
            //cout << points3[i][3] << endl;
            points3[i][j] = points3[i][j] / points3[i][3];
        }
    }

    for(i = 0; i < 14; i++)
    {
        points3[i][0] = (points3[i][0] * 300) + 300;
        points3[i][1] = (points3[i][1] * 300) + 300;
        cout << points3[i][0] << "       " << points3[i][1] << "          " << points3[i][2] << "         " << points3[i][3] << endl;
    }
}

void afficherMaison(double points3[][4], SDL_Surface *pixel, SDL_Surface *screen, SDL_Rect *position)
{
    // socle
    afficherLignes(points3, 0, 1, pixel, screen, position);
    afficherLignes(points3, 0, 2, pixel, screen, position);
    afficherLignes(points3, 1, 5, pixel, screen, position);
    afficherLignes(points3, 2, 3, pixel, screen, position);
    afficherLignes(points3, 4, 5, pixel, screen, position);

    // en dessous du toit
    afficherLignes(points3, 6, 7, pixel, screen, position);
    afficherLignes(points3, 6, 8, pixel, screen, position);
    afficherLignes(points3, 7, 9, pixel, screen, position);
    afficherLignes(points3, 8, 9, pixel, screen, position);

    //pilliers
    afficherLignes(points3, 0, 6, pixel, screen, position);
    afficherLignes(points3, 1, 7, pixel, screen, position);
    afficherLignes(points3, 2, 8, pixel, screen, position);
    afficherLignes(points3, 5, 9, pixel, screen, position);

    //porte
    afficherLignes(points3, 3, 10, pixel, screen, position);
    afficherLignes(points3, 4, 11, pixel, screen, position);
    afficherLignes(points3, 10, 11, pixel, screen, position);

    //toit
    afficherLignes(points3, 6, 12, pixel, screen, position);
    afficherLignes(points3, 12, 7, pixel, screen, position);
    afficherLignes(points3, 8, 13, pixel, screen, position);
    afficherLignes(points3, 13, 9, pixel, screen, position);
    afficherLignes(points3, 12, 13, pixel, screen, position);
}

double convertDegreRad(double degre)
{
    double rad;
    rad = 3.141592653589793 * (degre) / 180;
    return rad;
}
